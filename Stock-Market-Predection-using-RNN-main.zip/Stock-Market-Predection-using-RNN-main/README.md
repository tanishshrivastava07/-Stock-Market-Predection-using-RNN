This is used to determine a perticular stock of the company and predict the future value.
To yield a significant profit a successful predection on stock future price is determined.
